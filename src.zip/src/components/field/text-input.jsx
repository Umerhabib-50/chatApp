import React from 'react';
import {TextInput, View} from 'react-native';

// hook form
import {Controller} from 'react-hook-form';
import {Text} from 'react-native-paper';

export const CustomInput = ({control, name, errors, label, errorMessage}) => {
  return (
    <>
      <View>
        <Controller
          control={control}
          render={({field: {onChange, onBlur, value}}) => {
            return (
              <>
                <View>
                  <TextInput
                    value={value}
                    onChangeText={onChange}
                    textColor={'black'}
                  />
                </View>
              </>
            );
          }}
          name={name}
        />
        {errorMessage && (
          <Text color="red" variant={'labelSmall'}>
            {/* {errors[name].message === ''
              ? `${label} is required.`
              : password
              ? errors[name].message
              : name == 'contact' && errors[name].message} */}
            {errorMessage}
          </Text>
        )}
      </View>
    </>
  );
};
