export const config = {
  // SERVER_IP: 'http://173.249.30.193:122/api/v1',
  SERVER_IP: 'http://192.168.1.89:8000/api/v1',
};
